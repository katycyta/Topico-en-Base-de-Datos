#ifndef DATA_H
#define DATA_H


class Data
{
public:
    Data();
public:
    int idData;
    double score;
};

#endif // DATA_H
