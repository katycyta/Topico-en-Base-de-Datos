#include "movie.h"

Movie::Movie()
{

}

Movie::~Movie()
{

}
